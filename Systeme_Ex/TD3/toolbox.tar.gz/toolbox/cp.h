#include "toolbox.h"

void copy(const char *src, const char *dst, mode_t mode);