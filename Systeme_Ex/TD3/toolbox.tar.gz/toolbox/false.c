#include "toolbox.h"


int main_false(int argc, char *argv[])
{
    return 1;
}