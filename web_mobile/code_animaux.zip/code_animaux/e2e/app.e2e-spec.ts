import { AnimauxPage } from './app.po';

describe('animaux App', function() {
  let page: AnimauxPage;

  beforeEach(() => {
    page = new AnimauxPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
