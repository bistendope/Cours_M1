import { Component, OnInit } from '@angular/core';
import { AppComponent } from './app.component';
import { RouterModule, Router } from '@angular/router';
import { AnimalCategorie } from './animal-categorie';

@Component({
  selector: 'app-liste',
  template: `
  <h1>
    Les animaux par catégorie
  </h1>

  <div class="container">
    <div class="list-group">
      <a *ngFor="let animal of animaux" [routerLink]="['/listeCategorieAnimaux', animal.id]" class="list-group-item">
        <span class="badge badge-success">{{animal.nombre}}</span>
        <img src="../assets/images/{{animal.id}}.png" class="vignette">
        <!-- Alternative au [routerLink] : -->
        <!-- <strong (click)="listeCategorieAnimaux(animal.id)">{{animal.nom}}</strong> -->
        <span>{{animal.nom}}</span>
      </a>
    </div>
  </div>
  `
})
export class ListeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  animaux : AnimalCategorie[] =
    [
      { "id" : "afrique", "nom" : "Afrique", "nombre" : 17},
  		{ "id" : "animauxdelaferme", "nom" : "Animaux de la ferme", "nombre" : 12},
  		{ "id" : "asieetaustralie", "nom" : "Asie et Australie", "nombre" : 0},
  		{ "id" : "chevaux", "nom" : "Chevaux", "nombre" : 0},
  		{ "id" : "chiens", "nom" : "Chiens", "nombre" : 0},
  		{ "id" : "europe", "nom" : "Europe", "nombre" : 0},
  		{ "id" : "ocean", "nom" : "Océan", "nombre" : 0}
    ]

  listeCategorieAnimaux(id: string) {
    // Nécessaire si on utilise la navigation par évènement (click)
    this.router.navigate(['/listeCategorieAnimaux', id]);
 }
}
