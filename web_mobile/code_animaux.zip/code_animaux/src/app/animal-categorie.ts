export class AnimalCategorie {
  id : string;
  nom : string;
  nombre : number
}
