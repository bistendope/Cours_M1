export class Animal {
  Nom                   : string;
  Nom_scientifique      : string;
  Classification        : string;
  Habitat_naturel       : string;
  Origine_geographique  : string;
  Info                  : string;
  Description           : string;
  Infos_supp            : string;
  image                 : string;
}
