import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { ListeCategorieComponent } from './liste-categorie.component';
import { PageNotFoundComponent } from './page-not-found.component';
import { ListeComponent } from './liste.component';
import { DetailAnimalComponent } from './detail-animal.component';
import { AnimauxService } from './animaux.service';

const routes: Routes = [
  { path: 'accueil', component: AppComponent },
  { path: 'liste', component: ListeComponent },
  { path: 'listeCategorieAnimaux/:id', component: ListeCategorieComponent },
  { path: 'detailAnimal', component: DetailAnimalComponent },
  { path: '',   redirectTo: '/liste', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    ListeCategorieComponent,
    PageNotFoundComponent,
    ListeComponent,
    DetailAnimalComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes)
  ],
  providers: [AnimauxService],
  bootstrap: [AppComponent]
})

export class AppModule { }
