import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router';
import { Subscription } from 'rxjs';
// RxJS (pour Reactive Extensions for JavaScript) est un ensemble de bibliothèques pour composer des programmes asynchrones basés sur des événements et utilisant des séquences "d'Observables" et des opérateurs de requêtes fluides.
// Nous l'utilisons ici pour gérer les routes (ou URL) qui transportent les paramètres à traiter par le composant.
// Plus d'infos sur : github.com/Reactive-Extensions/RxJS
import 'rxjs/add/operator/map'; // Chemin précis si on doit inclure uniquement "map" (on peut arrêter le chemin plus tôt pour inclure plus de choses : exemple rxjs/add/operator pour inclure tous les opérateurs comme count, concat, ...)

// import { Http } from '@angular/http';
import { Animal } from './animal';
import { AnimauxService } from './animaux.service';

@Component({
  selector: 'app-liste-categorie',
  templateUrl: './liste-categorie.component.html'
})
export class ListeCategorieComponent implements OnInit {

  private categorieSelectionnee: string;
  private subscriptionParam: Subscription;
  private subscriptionData: Subscription;
  liste : Animal[] = [];

  constructor(
    private animauxService : AnimauxService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() { // Au lancement du composant
    // Souscrire à l'événement de la route (et accéder à ses paramètres)
    this.subscriptionParam = this.route.params.subscribe(
         (param: any) => {
           this.categorieSelectionnee = param['id'];
         });
    // Souscrire à l'obtention des données depuis le service animauxService
    this.subscriptionData = this.animauxService.obtenirAnimaux(this.categorieSelectionnee).subscribe(l => this.liste = l);
  }

  ngOnDestroy() { // A la fin du composant
    // Empêcher la fuite de mémoire en se désinscrivant
    this.subscriptionParam.unsubscribe();
    this.subscriptionData.unsubscribe();
  }

  detailAnimal(animal:Animal) {
    // Pour les besoins du détail de l'animal, on "fabrique" les données à trasférer dans un objet NavigationExtras
    // Cette version de navigation aurait pu être remplacée par la manière utilisée dans le composant liste.component
    // mais le passage simple de plusieurs arguments ne fonctionne pas malgré ce que raconte la doc Angular
    // (cf. doc dans cette page : https://angular.io/docs/ts/latest/guide/router.html chercher la ligne : this.router.navigate(['/heroes', { id: heroId, foo: 'foo' }]);)
    let navigationExtras: NavigationExtras = {
            queryParams: {
                "categorie": this.categorieSelectionnee,
                "nom": animal.Nom,
                "nomScientifique": animal.Nom_scientifique,
                "classification" : animal.Classification,
                "origineGeographique" : animal.Origine_geographique,
                "habitatNaturel" : animal.Habitat_naturel,
                "description" : animal.Description,
                "info" : animal.Info,
                "infosSupp" : animal.Infos_supp,
                "image" : animal.image
            }
        };
    this.router.navigate(['/detailAnimal'], navigationExtras);
  }
}
