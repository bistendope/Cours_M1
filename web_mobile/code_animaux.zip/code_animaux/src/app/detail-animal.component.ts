import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Animal } from './animal';
import { Subscription } from 'rxjs';
// import { ListeCategorieComponent } from './liste-categorie.component';
import { AnimauxService } from './animaux.service';


@Component({
  selector: 'app-detail-animal',
  template: `
    <h2>{{nom}}</h2>
    <div class="col-md-5">
      <img src="assets/{{categorie}}/{{image}}">
    </div>
    <div class="col-md-7">
      <h3>{{nomScientifique}} <small>(Nom scientifique) - {{classification}}</small></h3>
      <strong>Origine</strong> : {{origineGeographique}} - <strong>Habitat</strong> : {{habitatNaturel}}
      <p class="well well-sm">{{description}}</p>
      <p>{{info}}</p>
      <div class="alert alert-success" role="alert">{{infosSupp}}</div>
    </div>
  `
})

export class DetailAnimalComponent implements OnInit {

  categorie : string;
  nom : string;
  nomScientifique : string;
  classification : string;
  origineGeographique : string;
  habitatNaturel : string;
  description : string;
  info : string;
  infosSupp : string;
  image : string;
  //nom : string;
  //animals : Animal[] = [];
  // animal : Animal = {"Nom" : "Suricate debout",
  // "Nom_scientifique" : "Suricata suricatta",
  // "Classification" : "Espèce commune",
  // "Habitat_naturel" : "Désert",
  // "Origine_geographique" : "Afrique",
  // "Info" : "Petites mangoustes les suricates sont des mammifères au corps svelte et aux membres fins.",
  // "Description" : "Les suricates élisent domicile dans le désert où ils vivent en colonies avec leurs familles. Ces colonies comprennent une vingtaine de membres qui construisent ensemble des galeries souterraines. Pendant la journée les suricates creusent pour trouver de la nourriture ou jouent sous la vigilance d un suricate qui monte la garde. Les suricates utilisent leurs griffes pour déterrer les insectes les serpents les lézards les araignées les scorpions et les plantes. Parfois ces mammifères peuvent se battre ou faire la course ! Extrêmement sociables les suricates ont pour habitude de se toiletter entre eux et de partager leurs terriers avec d autres animaux. Le pelage multicolore de chaque suricate possède des rayures uniques.",
  // "Infos_supp" : "Deux suricates adultes pèsent moins lourd que 45 litres de lait.",
  // "image" : "suricatedebout.png"
  // };
  private subscriptionParam: Subscription;
  private subscriptionData: Subscription;

  constructor(
    private animauxService : AnimauxService,
    private route: ActivatedRoute) {
      //this.animal = this.animals.find(elem => elem.Nom == this.nom);
  }

  ngOnInit() {
    this.subscriptionParam =
      this.route.queryParams.subscribe(params => {
        this.categorie = params["categorie"];
        this.nom = params["nom"];
        this.nomScientifique = params["nomScientifique"];
        this.classification = params["classification"];
        this.origineGeographique = params["origineGeographique"];
        this.habitatNaturel = params["habitatNaturel"];
        this.description = params["description"];
        this.info = params["info"];
        this.infosSupp = params["infosSupp"];
        this.image = params["image"];
      });
    // Souscrire à l'événement de la route (et accéder à ses paramètres)
    // this.subscriptionParam =
    //   this.route.params.subscribe((param: any) => this.n = param['name']);
    //this.subscriptionData =
    //  this.animauxService.obtenirAnimaux('afrique').subscribe(l => this.animals = l);
      //.forEach(e => console.log(e));
    //console.log(this.animals);
    //this.animal = this.animals.find(elem => elem.Nom == this.nom);
  }

}
