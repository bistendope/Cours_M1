import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Animal } from './animal';
import 'rxjs/add/operator/map';

@Injectable()

export class AnimauxService {
  private http: Http;
  constructor(http : Http) {
    this.http = http;
  }

  obtenirAnimaux(categorie : string) {
    return this.http.get('assets/' + categorie + '/' + categorie + '.json')
      .map(reponse => <Animal[]>reponse.json().donnee);
      //.forEach(elem => console.log(elem.json().donnee)); // Pour vérifier sur la console ce qui revient du http.get
  }

}
